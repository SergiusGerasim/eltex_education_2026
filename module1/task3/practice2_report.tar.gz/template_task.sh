#!/usr/bin/env bash

script_name="$(basename "$0")"

if [[ "$script_name" == "template_task.sh" ]]; then
printf '%s\n' 'я бригадир, сам не работаю'
exit 1
fi

report_file="report_${script_name}.log"
cuckoo_fifo="/tmp/run/cuckoo.pid"
reply_fifo="/tmp/run/cuckoo.$$.reply"

cleanup() {
rm -f "$reply_fifo"
}

if [[ ! -p "$cuckoo_fifo" ]]; then
printf 'Error: cuckoo_fifo not found: %s\n' "$cuckoo_fifo" >&2
exit 1
fi

if [[ -e "$reply_fifo" ]]; then
printf 'Error: path already exists: %s\n' "$reply_fifo" >&2
exit 1
fi

if ! mkfifo "$reply_fifo"; then
    printf 'Error: cannot create FIFO: %s\n' "$reply_fifo" >&2
    exit 1
fi

trap cleanup EXIT

printf '%s [%s] Скрипт запущен\n' "$(date '+%F %T')" "$$" >> "$report_file"

printf '%s[%s]: how much time do I have?\n' "$script_name" "$$" > "$cuckoo_fifo"

if ! IFS= read -r n < "$reply_fifo"; then
printf 'Error: bad answer from cuckoo\n' >&2
exit 1
fi

if [[ ! "$n" =~ ^[0-9]+$ ]] || ((n < 2 || n > 10)); then
printf 'Error: uncorrect unswer from cuckoo: %s\n' "$n" >&2
exit 1
fi

sleep "$n"

printf '%s [%s] Скрипт завершился, работал %s секунд.\n' "$(date '+%F %T')" "$$" "$n" >> "$report_file"
