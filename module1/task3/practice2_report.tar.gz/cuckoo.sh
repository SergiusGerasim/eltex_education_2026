#!/usr/bin/env bash

mkdir -p /tmp/run

fifo="/tmp/run/cuckoo.pid"
log_file="$HOME/cuckoo.log"

if [[ ! -p "$fifo" ]]; then
mkfifo "$fifo"
fi


log_message() {
printf '%s %s\n' "$(date '+%F %T')" "$1" >> "$log_file"
}


log_message "Startup!"

shutdown() {
log_message "Shutdown!"
exit 0
}

trap shutdown SIGINT SIGTERM

while true; do
if IFS= read -r message < "$fifo"; then
if [[ "$message" =~ ^([[:alnum:]_.-]+)\[([0-9]+)\]:[[:space:]]how[[:space:]]much[[:space:]]time[[:space:]]do[[:space:]]I[[:space:]]have\?$ ]]; then
name="${BASH_REMATCH[1]}"
pid="${BASH_REMATCH[2]}"

n=$((RANDOM % 9 + 2))

reply_fifo="/tmp/run/cuckoo.${pid}.reply"

log_message "$name[$pid] $n"

if [[ -p "$reply_fifo" ]]; then
printf '%s\n' "$n" > "$reply_fifo"
else
printf 'response channel %s not found\n' "$reply_fifo" >&2
fi
fi
fi
done
