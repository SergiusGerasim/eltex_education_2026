#!/usr/bin/env bash

base_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
config_file="$base_dir/observer.conf"
log_file="$base_dir/observer.log"

log_message() {
printf '%s %s\n' "$(date '+%F %T')" "$1" >> "$log_file"
}

is_running() {
local wanted="$1"
local proc
local argument

for proc in /proc/[0-9]*; do
[[ -r "$proc/cmdline" ]] || continue
while IFS= read -r -d '' argument; do
if [[ "$argument" == "$wanted" ]]; then
return 0
fi
done < "$proc/cmdline" 2>/dev/null
done
return 1
}

if [[ ! -f "$config_file" ]]; then
printf "Error: config file not found: %s\n" "$config_file" >2&
exit 1
fi

while IFS= read -r entry || [[ -n "$entry" ]]; do
[[ -z "$entry" ]] && continue
[[ "$entry" == \#* ]] && continue

if [[ "$entry" = /* ]]; then
script="$entry"
else
script="$base_dir/$entry"
fi

if [[ ! -f "$script" ]]; then
printf 'script not foud: %s\n' "$script" >&2
continue
fi

if [[ ! -x "$script" ]]; then
printf 'script is not executable: %s\n' "$script" >&2
continue
fi

if ! is_running "$script"; then
script_name="$(basename "$script")"
output_file="$base_dir/${script_name}.out"

(
cd "$base_dir" || exit 1
nohup "$script" </dev/null >> "$output_file" 2>&1
) &
child_pid=$!
log_message "Перезапущен $script_name [$child_pid]"
fi
done < "$config_file"
